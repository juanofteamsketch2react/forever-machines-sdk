// Copyright (c) 2026 Juan Maguid, Temperamento. Forever Machines SDK License.
package net.forevermachines.sdk

internal object NativeCore {
    init { System.loadLibrary("fmsdk") }

    interface Requests {
        fun onRequest(json: String)
        fun onLog(line: String)
        /** On the page's thread: there is a new picture (only while watchScreen is on). */
        fun onFrame()
        /** On the page's thread: a control changed (only while watchControls is on), with the list as JSON. */
        fun onControls(json: String)
    }

    @JvmStatic external fun create(root: String, sampleRate: Double, requests: Requests): Long
    @JvmStatic external fun boot(h: Long, code: String, name: String, skin: String, state: String, seed: Double, effect: String, effectMix: Double, extra: String): String?
    @JvmStatic external fun bootPage(h: Long): String?
    @JvmStatic external fun start(h: Long, fps: Double)
    @JvmStatic external fun setFps(h: Long, fps: Double)
    @JvmStatic external fun fps(h: Long): Double
    @JvmStatic external fun drawing(h: Long): Boolean
    @JvmStatic external fun setReverb(h: Long, scale: Double)
    @JvmStatic external fun screenVersion(h: Long): Long
    @JvmStatic external fun watchScreen(h: Long, on: Boolean)
    @JvmStatic external fun watchControls(h: Long, on: Boolean)
    @JvmStatic external fun post(h: Long, json: String)
    @JvmStatic external fun reply(h: Long, id: Int, json: String)
    @JvmStatic external fun queue(h: Long, js: String)
    @JvmStatic external fun evaluate(h: Long, js: String): String
    @JvmStatic external fun controlsCached(h: Long): String
    @JvmStatic external fun render(h: Long, left: FloatArray, right: FloatArray, frames: Int)
    @JvmStatic external fun takePeak(h: Long): Float
    @JvmStatic external fun setGain(h: Long, gain: Double, seconds: Double)
    @JvmStatic external fun setVolume(h: Long, volume: Double)
    @JvmStatic external fun screen(h: Long, dims: FloatArray): ByteArray?
    @JvmStatic external fun screenInto(h: Long, bitmap: android.graphics.Bitmap?, dims: FloatArray): Boolean
    @JvmStatic external fun pointer(h: Long, type: String, x: Float, y: Float, buttons: Int)
    @JvmStatic external fun destroy(h: Long)
}
