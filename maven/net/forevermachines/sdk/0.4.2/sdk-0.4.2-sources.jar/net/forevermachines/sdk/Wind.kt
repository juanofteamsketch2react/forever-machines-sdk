// Copyright (c) 2026 Juan Maguid, Temperamento. Forever Machines SDK License.
// Wind down, as sdk/src/wind.js: it plays on for about the time chosen (±15%), then the ending (one to four minutes):
// the machines leave out more and more notes, darken, fade and sag a little in tempo, unevenly, until everything stops.
package net.forevermachines.sdk

import android.os.Handler
import android.os.Looper
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

data class WindState(
    val on: Boolean = false,
    val ending: Boolean = false,
    val wound: Boolean = false,
    val minutes: Int = 0,
    val left: Double = 1.0,
    val v: Double = 0.0,
    val minutesLeft: Int = 0,
)

internal class Wind(
    var apply: (Double) -> Unit = {},
    var tempo: (Double) -> Unit = {},
    var stop: () -> Unit = {},
    var change: (WindState) -> Unit = {},
    var now: () -> Double = { System.currentTimeMillis() / 1000.0 },
    var random: () -> Double = { Math.random() },
    private val handler: Handler? = Looper.myLooper()?.let { Handler(it) },
) {
    companion object { const val HUSH = 4.0 }

    private var on = false; private var end = false; private var fell = false
    private var min = 0; private var t0 = 0.0; private var endAt = 0.0; private var endLen = 0.0
    private var v = 0.0; private var left = 1.0; private var wob = 0.0; private var hushAt = 0.0
    private val ticker = object : Runnable { override fun run() { tick(); if (on) handler?.postDelayed(this, 1000) } }

    val state: WindState
        get() = WindState(on, end, fell, min, left, v, if (on) max(1, ceil((endAt + endLen - now()) / 60).toInt()) else 0)

    fun start(minutes: Double): WindState {
        var m = if (minutes.isFinite() && minutes > 0) minutes else 30.0
        m = max(1.0, min(240.0, m.roundToInt().toDouble()))
        val t = now()
        val len = (if (m <= 5) m * 60 * 0.4 else min(240.0, max(60.0, m * 60 * 0.12))) * (0.8 + random() * 0.4)
        on = true; end = false; fell = false; min = m.toInt(); t0 = t; v = 0.0; left = 1.0; wob = random() * 6.3; hushAt = 0.0; endLen = len
        endAt = t + if (m <= 5) max(0.0, m * 60 - len) * (0.9 + random() * 0.2) else m * 60 * (0.85 + random() * 0.3)
        apply(0.0)
        handler?.removeCallbacks(ticker); handler?.postDelayed(ticker, 1000)
        change(state)
        return state
    }

    fun cancel() = off(false)

    fun tick() {
        if (!on) return
        val t = now()
        left = max(0.0, 1 - (t - t0) / max(0.001, endAt + endLen - t0))
        if (t < endAt) { change(state); return }
        end = true
        val u = min(1.0, (t - endAt) / endLen)
        v = min(1.0, max(v, u + 0.05 * sin(t / 6.5 + wob) * (1 - u)))
        apply(v)
        tempo(1 - 0.12 * v)
        change(state)
        if (u >= 1) { if (hushAt == 0.0) hushAt = t else if (t - hushAt >= HUSH) off(true) }
    }

    private fun off(f: Boolean) {
        if (!on) return
        handler?.removeCallbacks(ticker)
        on = false; end = false; v = 0.0; fell = f
        if (f) stop()
        tempo(1.0)
        if (handler != null) handler.postDelayed({ apply(0.0) }, if (f) 1500 else 0) else apply(0.0)
        change(state)
    }
}
