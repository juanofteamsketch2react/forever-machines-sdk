// Copyright (c) 2026 Juan Maguid, Temperamento. Forever Machines SDK License: free to try and for non-commercial use,
// commercial use needs a license. See LICENSE (https://forevermachines.net/sdk/LICENSE.txt).
//
// Forever Machines, native: generative audio that never repeats and ends by itself. The same API as the web SDK
// (@forevermachines/sdk), with the machines running natively (FM Core: QuickJS and the apps' own audio engine).
//
//   val fm = FMSession(context)
//   val tide = fm.mount("slow-tide")      // off the main thread: it may download
//   fm.power(true)
//   tide.macro(1, 0.4)
//   fm.drift(true)
//   fm.windDown(30.0)
package net.forevermachines.sdk

import android.content.Context
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class FMException(message: String) : Exception(message)

/** One of a machine's controls. Macro 1–8 are the first eight knobs (not the tempo), then switches and menus. */
data class FMControl(val key: String, val label: String, val kind: String, val section: String, val value: Double, val text: String?, val options: List<String> = emptyList())

class FMSession(context: Context, val options: Options = Options()) {
    data class Options(
        /** Where machines not bundled with the SDK are fetched from. */
        val base: String = "https://forevermachines.net",
        /** Machines may fetch over the network (the weather for m.world, from Open-Meteo). false: no network at all. */
        val network: Boolean = true,
        /** Ask for audio focus when playing, and stop when another app takes it for good. */
        val audioFocus: Boolean = true,
    )

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    internal val io = Executors.newCachedThreadPool()
    internal val root: String = unpack(app)
    private val output = AudioOutput(app)
    internal val renderLock get() = output.renderLock
    private val list = CopyOnWriteArrayList<FMMachine>()
    private val wind = Wind(handler = main)
    private var driftOn = false
    private var bpm = 0.0
    private var focus: AudioFocusRequest? = null

    val machines: List<FMMachine> get() = list.toList()
    @Volatile var isPlaying = false; private set
    /** Called on the main thread once a second while winding down, and when it starts, ends or is cancelled. */
    var onWind: ((WindState) -> Unit)? = null
    val windState: WindState get() = wind.state

    init {
        wind.apply = { v -> all("""{"fm":"wind","v":$v}""") }
        wind.tempo = { f -> if (bpm > 0) all("""{"fm":"tempo","bpm":${bpm * f},"anchor":0}""") }
        wind.stop = { power(false) }
        wind.change = { s -> onWind?.invoke(s) }
    }

    /** Mounts a machine by name: one bundled with the SDK (slow-tide, night-choir, seven-bowls, lotus-pond, rain-window,
     *  long-breath), else /machines/<name>.js from options.base (a species of the collection, e.g. "loom"; for a numbered
     *  machine exactly as the site plays it, use mountNumber). effect: a Forever Effect's id (see effects()) run inside
     *  the machine, at effectMix. Call it off the main thread. */
    fun mount(name: String, skin: String? = null, seed: Double = 1.0, effect: String? = null, effectMix: Double = 0.5): FMMachine {
        val bundled = File(root, "machines/$name.js")
        val code = if (bundled.exists()) bundled.readText() else fetchText("${base()}/machines/$name.js") ?: throw FMException("no machine called $name")
        return mount(code, name, skin, seed, effect, effectMix)
    }

    /** Mounts No. [number] of the collection exactly as the site plays it: its species, seed, skin and name (see catalog();
     *  a bonus machine is 501 and up, as in its address). Needs the network the first time. Off the main thread. */
    fun mountNumber(number: Int, effect: String? = null, effectMix: Double = 0.5): FMMachine {
        val c = catalog().firstOrNull { it.number == number } ?: throw FMException("no No. $number")
        val code = fetchText("${base()}/machines/${c.file}") ?: throw FMException("no machine ${c.file}")
        val extra = JSONObject().put("index", c.number - 1).put("no", c.no).put("original", c.original).toString()
        return mountSpec(FMMachine.Spec(code, c.name, c.themeJson, c.seed, extra, loadEffect(effect), effectMix))
    }

    /** Mounts a machine from its source. Off the main thread when it has an effect (it is downloaded). */
    fun mount(code: String, name: String, skin: String? = null, seed: Double = 1.0, effect: String? = null, effectMix: Double = 0.5): FMMachine =
        mountSpec(FMMachine.Spec(code, name, skin ?: "", seed, "{}", loadEffect(effect), effectMix))

    private fun mountSpec(spec: FMMachine.Spec): FMMachine {
        val m = FMMachine(this, spec)
        m.handle = boot(spec, "{}", m.requests, isPlaying)
        m.isPlaying = isPlaying
        list.add(m)
        output.machines = list.toList()
        return m
    }

    // a core for the machine, started and told what the session is doing
    internal fun boot(s: FMMachine.Spec, state: String, requests: NativeCore.Requests, playing: Boolean): Long {
        val h = NativeCore.create(root, output.sampleRate.toDouble(), requests)
        val extra = if (s.effect == null) s.extra else JSONObject(s.extra).put("insertTitle", s.effect.title).toString()
        NativeCore.boot(h, s.code, s.name, s.skin, state, s.seed, s.effect?.code ?: "", s.effectMix, extra)?.let {
            NativeCore.destroy(h); throw FMException("the machine did not start: $it")
        }
        NativeCore.start(h, 30.0)
        NativeCore.post(h, """{"fm":"power","on":$playing}""")
        if (driftOn) NativeCore.post(h, """{"fm":"drift","on":true}""")
        if (bpm > 0) NativeCore.post(h, """{"fm":"tempo","bpm":$bpm,"anchor":0}""")
        if (wind.state.on) NativeCore.post(h, """{"fm":"wind","v":${wind.state.v}}""")
        return h
    }

    internal fun base() = options.base.trimEnd('/')

    @Volatile private var catalogCache: Pair<Long, List<FMCatalogEntry>>? = null
    @Volatile private var effectsCache: List<FMEffect>? = null

    /** Every machine born so far, in order, then the bonus machines: number, name, species, seed, skin. Computed by the
     *  site's own catalog.js from its registry and the date (kept 10 minutes); offline, the bundled registry. Off the main thread. */
    fun catalog(): List<FMCatalogEntry> {
        catalogCache?.let { if (System.currentTimeMillis() - it.first < 600_000) return it.second }
        val reg = io.submit<String?> { fetchText("${base()}/machines/registry.json") }
        val themes = io.submit<String?> { fetchText("${base()}/themes.js") }
        val cat = io.submit<String?> { fetchText("${base()}/catalog.js") }
        val r = reg.get(); val t = themes.get(); val c = cat.get()
        val online = r != null && t != null && c != null   // (the site's catalog with the site's skins, or all bundled)
        val h = NativeCore.create(root, 48000.0, object : NativeCore.Requests { override fun onRequest(json: String) {} override fun onLog(line: String) {} })
        try {
            NativeCore.bootPage(h)?.let { throw FMException("the catalog: $it") }
            NativeCore.evaluate(h, if (online) t!! else File(root, "public/themes.js").readText())
            NativeCore.evaluate(h, if (online) c!! else File(root, "public/catalog.js").readText())
            val json = NativeCore.evaluate(h, """
                (function (reg) { const b = FMCatalog.build(reg, Date.now());
                  return JSON.stringify([...b.catalog, ...b.bonus].map((c) => ({ number: c.i + 1, no: c.no || String(c.i + 1).padStart(3, '0'),
                    name: c.name, species: c.arch.title || c.arch.id, speciesId: c.arch.id, file: c.arch.file, seed: c.seed, skin: c.theme.name,
                    theme: JSON.stringify(c.theme), blurb: c.arch.blurb || '', thought: c.thought || '', original: !!c.original, bonus: !!c.bonus, born: c.born })));
                })(${r ?: File(root, "public/machines/registry.json").readText()})""")
            val a = try { JSONArray(json) } catch (_: Exception) { throw FMException("the catalog: ${json.take(200)}") }
            val out = (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                FMCatalogEntry(o.getInt("number"), o.getString("no"), o.getString("name"), o.getString("species"), o.getString("speciesId"),
                    o.getString("file"), o.getDouble("seed"), o.getString("skin"), o.optString("blurb"), o.optString("thought"),
                    o.optBoolean("original"), o.optBoolean("bonus"), o.optLong("born"), o.getString("theme"))
            }
            if (online) catalogCache = System.currentTimeMillis() to out
            return out
        } finally { NativeCore.destroy(h) }
    }

    /** The Forever Effects collection (those released so far): id, title, blurb. Off the main thread. */
    fun effects(): List<FMEffect> {
        effectsCache?.let { return it }
        val text = fetchText("${base()}/effects/fx/registry.json") ?: throw FMException("the effects did not load")
        val a = JSONObject(text).optJSONArray("effects") ?: JSONArray()
        val now = System.currentTimeMillis()
        val out = (0 until a.length()).mapNotNull { i ->
            val e = a.getJSONObject(i)
            val rel = e.optString("release")
            if (rel.isNotEmpty()) { val t = try { java.time.Instant.parse(if (rel.length == 10) rel + "T00:00:00Z" else rel).toEpochMilli() } catch (_: Exception) { 0L }; if (t > now) return@mapNotNull null }
            FMEffect(e.getString("id"), e.optString("title", e.getString("id")), e.optString("blurb"), e.getString("file"))
        }
        effectsCache = out
        return out
    }

    internal fun loadEffect(id: String?): FMEffectCode? {
        if (id == null) return null
        val e = effects().firstOrNull { it.id == id || it.file == id || it.file == "$id.js" } ?: throw FMException("no effect called $id")
        return FMEffectCode(e.title, fetchText("${base()}/effects/fx/${e.file}") ?: throw FMException("effect ${e.file} did not load"))
    }

    internal fun swapped() { output.machines = list.toList() }

    /** Every machine on or off. To play on with the screen off, run the session from a foreground service. */
    fun power(on: Boolean) {
        if (on) { requestFocus(); output.start() }
        isPlaying = on
        all("""{"fm":"power","on":$on}""")
        for (m in list) m.isPlaying = on
        if (!on) { main.postDelayed({ if (!isPlaying) output.pause() }, 400); abandonFocus() }
    }

    /** The first smooth knobs wander slowly, so it never repeats exactly. */
    fun drift(on: Boolean) { driftOn = on; all("""{"fm":"drift","on":$on}""") }

    /** A shared tempo for the machines that can follow one (0: each its own). */
    fun tempo(bpm: Double) { this.bpm = max(0.0, bpm); all("""{"fm":"tempo","bpm":${this.bpm},"anchor":0}""") }

    /** The music ends by itself in about [minutes] (1–240): never exactly, never twice alike. Call it on the main thread. */
    fun windDown(minutes: Double = 30.0): WindState { if (!isPlaying) power(true); return wind.start(minutes) }
    fun cancelWindDown() = wind.cancel()
    fun stop() { wind.cancel(); power(false) }

    /** Everything off and away. */
    fun destroy() { stop(); for (m in list.toList()) m.destroy(); output.release(); io.shutdown() }

    internal fun remove(m: FMMachine) { list.remove(m); output.machines = list.toList() }
    private fun all(json: String) { for (m in list) m.post(json) }

    private fun requestFocus() {
        if (!options.audioFocus || focus != null) return
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioOutput.attributes)
            .setOnAudioFocusChangeListener({ change -> if (change == AudioManager.AUDIOFOCUS_LOSS) stop() }, main)
            .build()
        am.requestAudioFocus(req)
        focus = req
    }
    private fun abandonFocus() {
        val f = focus ?: return
        (app.getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(f)
        focus = null
    }

    internal fun fetchText(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 15000
        if (c.responseCode in 200..299) c.inputStream.bufferedReader().readText() else null
    } catch (_: Exception) { null }

    private companion object {
        // the page files, from the AAR's assets into the app's own folder once per SDK version (FM Core reads files)
        fun unpack(ctx: Context): String {
            val dir = File(ctx.noBackupFilesDir, "forevermachines-${BuildConfig.SDK_VERSION}")
            val done = File(dir, ".done")
            if (done.exists()) return dir.path
            dir.deleteRecursively()
            fun copy(asset: String, to: File) {
                val names = ctx.assets.list(asset) ?: emptyArray()
                if (names.isEmpty()) { to.parentFile?.mkdirs(); ctx.assets.open(asset).use { i -> to.outputStream().use { i.copyTo(it) } } }
                else for (n in names) copy("$asset/$n", File(to, n))
            }
            copy("fm", dir)
            done.writeText("ok")
            return dir.path
        }
    }
}

/** One machine of the collection, as the site shows it. number: 1, 2, 3 … (a bonus machine 501 and up); no: "013" or
 *  "015½"; species: the machine it is a variation of; original: the first of its species; born: ms since 1970. */
data class FMCatalogEntry(
    val number: Int, val no: String, val name: String, val species: String, val speciesId: String, val file: String,
    val seed: Double, val skin: String, val blurb: String, val thought: String, val original: Boolean, val bonus: Boolean,
    val born: Long, internal val themeJson: String,
)

/** A Forever Effect: something that runs inside a machine, in its own audio. */
data class FMEffect(val id: String, val title: String, val blurb: String, internal val file: String)

internal class FMEffectCode(val title: String, val code: String)

class FMMachine internal constructor(private val session: FMSession, private var spec: Spec) {
    internal data class Spec(val code: String, val name: String, val skin: String, val seed: Double, val extra: String, val effect: FMEffectCode?, val effectMix: Double)

    val name: String get() = spec.name
    /** The Forever Effect running inside it, if any (its title). */
    val effectTitle: String? get() = spec.effect?.title
    internal var handle = 0L
    @Volatile var isPlaying = false; internal set

    /** Puts a Forever Effect inside the machine (its id, from effects()), or takes it off (null). The machine starts again
     *  with the same knobs, power, drift and wind; the amount can then move freely with effectMix. Off the main thread. */
    fun effect(id: String?, mix: Double? = null) {
        val old = handle
        if (old == 0L) return
        spec = spec.copy(effect = session.loadEffect(id), effectMix = mix ?: spec.effectMix)
        val state = NativeCore.evaluate(old, "JSON.stringify(__fmState || {})").ifEmpty { "{}" }
        val next = session.boot(spec, state, requests, isPlaying)
        synchronized(session.renderLock) { handle = next }
        session.swapped()
        NativeCore.destroy(old)
    }

    /** How much of the effect (0–1), without restarting. */
    fun effectMix(v: Double) {
        spec = spec.copy(effectMix = min(1.0, max(0.0, v)))
        post("""{"fm":"insert-mix","v":${spec.effectMix}}""")
    }

    /** The output's loudest moment since last asked (0 to about 1), for a meter or a lantern. */
    val level: Float get() = if (handle != 0L) NativeCore.takePeak(handle) else 0f

    fun power(on: Boolean) { isPlaying = on; post("""{"fm":"power","on":$on}""") }

    /** The colours of the skin it wears, as CSS colours by role: page, page-ink, dev (the device), head, line, ink, dim,
     *  accent, accent2, accent-ink, track, field, field-ink, screen, screen-ink, screen-alt, screen-dim. Enough to dress a
     *  panel of your own in the machine's look. */
    val colors: Map<String, String>
        get() {
            if (handle == 0L) return emptyMap()
            val o = try { JSONObject(NativeCore.evaluate(handle, "JSON.stringify((globalThis.__fmTheme && __fmTheme.vars) || {})")) } catch (_: Exception) { return emptyMap() }
            return o.keys().asSequence().associateWith { o.optString(it) }
        }

    /** The machine's controls, in the order the machine made them. */
    fun controls(): List<FMControl> {
        if (handle == 0L) return emptyList()
        val a = try { JSONArray(NativeCore.evaluate(handle, "__fmDeliver({ fm: 'controls', native: true }); JSON.stringify(__fmControls)")) } catch (_: Exception) { return emptyList() }
        return (0 until a.length()).mapNotNull { i ->
            val c = a.optJSONObject(i) ?: return@mapNotNull null
            val opts = c.optJSONArray("options")
            FMControl(c.optString("key"), c.optString("label"), c.optString("kind"), c.optString("sec"), c.optDouble("v", 0.0), if (c.has("text")) c.optString("text") else null,
                if (opts == null) emptyList() else (0 until opts.length()).map { opts.optString(it) })
        }
    }

    /** Macro 1–8: the first eight knobs (not the tempo), then switches and menus. The same as the web SDK and Live. */
    fun macros(): List<FMControl> {
        val all = controls()
        val tempo = Regex("^(tempo|bpm|speed)$", RegexOption.IGNORE_CASE)
        return (all.filter { it.kind == "knob" && !tempo.matches(it.label) } + all.filter { it.kind == "toggle" || it.kind == "select" }).take(8)
    }

    /** Moves Macro n (1–8) to v (0–1). false if the machine has no such macro. */
    fun macro(n: Int, v: Double): Boolean {
        val list = macros()
        if (n < 1 || n > list.size) return false
        set(list[n - 1].key, v)
        return true
    }

    /** Sets any control by its key (from controls()) to v (0–1). */
    fun set(key: String, v: Double) = post("""{"fm":"cc","key":${JSONObject.quote(key)},"v":${min(1.0, max(0.0, v))}}""")

    /** Presses one of the machine's buttons (kind "button"), by its key. */
    fun press(key: String) = post("""{"fm":"press","key":${JSONObject.quote(key)}}""")

    /** A MIDI note, answered in the machine's own voice. */
    fun note(n: Int, velocity: Int = 100, on: Boolean = true) = post("""{"fm":"note-in","n":$n,"v":$velocity,"on":$on}""")

    /** The machine's screen as last drawn, for a device view of your own (null until it has one). */
    fun screenBitmap(): Bitmap? {
        if (handle == 0L) return null
        val dims = FloatArray(4)
        val px = NativeCore.screen(handle, dims) ?: return null
        screenSize = dims[2] to dims[3]
        return Bitmap.createBitmap(dims[0].toInt(), dims[1].toInt(), Bitmap.Config.ARGB_8888).apply { copyPixelsFromBuffer(ByteBuffer.wrap(px)) }
    }
    /** Lays the machine's screen out at this size, in dp: the machines that can (all six sleep machines) redraw to fill
     *  it, tall or wide, instead of keeping their own proportions. Call it again when your view changes size. */
    fun fitScreen(width: Float, height: Float) = post("""{"fm":"focus","mode":"screen","fill":{"w":${width.toInt()},"h":${height.toInt()}}}""")

    /** The screen's size in its own units (CSS pixels), for pointer(). */
    var screenSize: Pair<Float, Float> = 0f to 0f; private set
    /** A touch on the screen, in screenSize units: "pointerdown", "pointermove", "pointerup". */
    fun pointer(type: String, x: Float, y: Float, down: Boolean) { if (handle != 0L) NativeCore.pointer(handle, type, x, y, if (down) 1 else 0) }
    /** How often the machine runs its timers and draws (5–60). Lower it while nothing shows the screen. */
    var framesPerSecond: Double
        get() = if (handle != 0L) NativeCore.fps(handle) else 0.0
        set(v) { if (handle != 0L) NativeCore.setFps(handle, v) }

    fun destroy() {
        val h = handle
        if (h == 0L) return
        session.remove(this)
        synchronized(session.renderLock) { handle = 0L }
        NativeCore.destroy(h)
    }

    internal fun post(json: String) { if (handle != 0L) NativeCore.post(handle, json) }

    // what the page asks for: a fetch (the weather), the mic. Anything else is told it is not here.
    internal val requests = object : NativeCore.Requests {
        override fun onLog(line: String) { android.util.Log.d("ForeverMachines", "$name: $line") }
        override fun onRequest(json: String) {
            val o = try { JSONObject(json) } catch (_: Exception) { return }
            if (!o.has("id")) {
                if (o.optString("type") == "mic") { val h = handle; if (h != 0L) NativeCore.queue(h, "__fmMic(0, { error: 'no microphone here' })") }
                return
            }
            val id = o.getInt("id")
            fun reply(v: JSONObject) { val h = handle; if (h != 0L) NativeCore.reply(h, id, v.toString()) }
            if (o.optString("type") != "fetch" || !session.options.network) { reply(JSONObject().put("error", "not available here")); return }
            session.io.execute {
                try {
                    val c = URL(o.getString("url")).openConnection() as HttpURLConnection
                    c.requestMethod = o.optString("method", "GET")
                    c.connectTimeout = 10000; c.readTimeout = 15000
                    if (o.has("body")) { c.doOutput = true; c.outputStream.use { it.write(o.getString("body").toByteArray()) } }
                    val code = c.responseCode
                    val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                    reply(JSONObject().put("status", code).put("body", body))
                } catch (e: Exception) { reply(JSONObject().put("error", e.message ?: "fetch failed")) }
            }
        }
    }
}

// one AudioTrack for the session: a thread renders every mounted machine, sums them and writes float stereo
internal class AudioOutput(ctx: Context) {
    companion object {
        val attributes: AudioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
        const val BLOCK = 256
    }
    val sampleRate: Int = (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
        .getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull()?.takeIf { it > 0 } ?: 48000
    @Volatile var machines: List<FMMachine> = emptyList()
    val renderLock = Any()   // (held while a block renders, and while a machine is destroyed)
    private var track: AudioTrack? = null
    private var thread: Thread? = null
    @Volatile private var running = false

    @Synchronized fun start() {
        if (track == null) {
            val fmt = AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
            val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
            track = AudioTrack.Builder().setAudioAttributes(attributes).setAudioFormat(fmt).setBufferSizeInBytes(max(min, BLOCK * 8 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM).setPerformanceMode(AudioTrack.PERFORMANCE_MODE_NONE).build()
        }
        track!!.play()
        if (running) return
        running = true
        thread = Thread({ loop() }, "ForeverMachines audio").apply { priority = Thread.MAX_PRIORITY; start() }
    }

    private fun loop() {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
        val l = FloatArray(BLOCK); val r = FloatArray(BLOCK); val out = FloatArray(BLOCK * 2)
        while (running) {
            out.fill(0f)
            synchronized(renderLock) {
                for (m in machines) {
                    val h = m.handle
                    if (h == 0L) continue
                    NativeCore.render(h, l, r, BLOCK)
                    for (i in 0 until BLOCK) { out[2 * i] += l[i]; out[2 * i + 1] += r[i] }
                }
            }
            val t = track ?: break
            if (t.write(out, 0, out.size, AudioTrack.WRITE_BLOCKING) < 0) break
        }
    }

    @Synchronized fun pause() {
        running = false
        thread?.join(500); thread = null
        track?.pause(); track?.flush()
    }

    @Synchronized fun release() { pause(); track?.release(); track = null }
}
